let result = document.getElementById("result");
let clear = document.getElementById("clear");
let backspace = document.getElementById("backspace");
let equals = document.getElementById("equals");
let decimal = document.getElementById("decimal");

function handleClick(e) {
  let buttonValue = e.target.innerText;
  let currentValue = result.innerText;

  if (buttonValue === "C") {
    result.innerText = "0";
  } else if (buttonValue === "←") {
    result.innerText = currentValue.slice(0, -1);
  } else if (buttonValue === "=") {
    result.innerText = eval(currentValue);
  } else if (buttonValue === ".") {
    if (!currentValue.includes(".")) {
      result.innerText += buttonValue;
    }
  } else {
    if (currentValue === "0") {
      result.innerText = buttonValue;
    } else {
      result.innerText += buttonValue;
    }
  }
}

clear.addEventListener("click", handleClick);
backspace.addEventListener("click", handleClick);
equals.addEventListener("click", handleClick);
decimal.addEventListener("click", handleClick);

let operators = document.querySelectorAll(".button:not(#clear):not(#backspace):not(#equals):not(#decimal)");

for (let operator of operators) {
  operator.addEventListener("click", handleClick);
}
